#SGP实验
# R50C100
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SGP --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SGP --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.1 --B 3 --model ResNet50 --dataset cifar100 --optimizer SGP --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.1 --B 8 --model ResNet50 --dataset cifar100 --optimizer SGP --type ForceRandom --topology ./topology/Ran6.txt

# R18C10
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SGP --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SGP --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.01 --B 3 --model ResNet18 --dataset cifar10 --optimizer SGP --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.01 --B 8 --model ResNet18 --dataset cifar10 --optimizer SGP --type ForceRandom --topology ./topology/Ran6.txt

#MSGP实验
# R50C100
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer MSGP --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer MSGP --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.1 --B 3 --model ResNet50 --dataset cifar100 --optimizer MSGP --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.1 --B 8 --model ResNet50 --dataset cifar100 --optimizer MSGP --type ForceRandom --topology ./topology/Ran6.txt

# R18C10
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer MSGP --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer MSGP --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.01 --B 3 --model ResNet18 --dataset cifar10 --optimizer MSGP --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.01 --B 8 --model ResNet18 --dataset cifar10 --optimizer MSGP --type ForceRandom --topology ./topology/Ran6.txt

#SADDOPT实验
# R50C100
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SADDOPT --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SADDOPT --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.1 --B 3 --model ResNet50 --dataset cifar100 --optimizer SADDOPT --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.1 --B 8 --model ResNet50 --dataset cifar100 --optimizer SADDOPT --type ForceRandom --topology ./topology/Ran6.txt

# R18C10
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SADDOPT --type Static --topology ./topology/Full6.txt
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SADDOPT --type Static --topology ./topology/DC6.txt
# python main.py --lr 0.01 --B 3 --model ResNet18 --dataset cifar10 --optimizer SADDOPT --type Exponential --topology ./topology/Exp6.txt
# python main.py --lr 0.01 --B 8 --model ResNet18 --dataset cifar10 --optimizer SADDOPT --type ForceRandom --topology ./topology/Ran6.txt

#SGAP实验
# R50C100
#python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SGAP --type Static --topology ./topology/Full6.txt --k 0.001 --v 0.1
#python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer SGAP --type Static --topology ./topology/DC6.txt --k 0.001 --v 0.1
#python main.py --lr 0.1 --B 3 --model ResNet50 --dataset cifar100 --optimizer SGAP --type Exponential --topology ./topology/Exp6.txt --k 0.001 --v 0.1
#python main.py --lr 0.1 --B 8 --model ResNet50 --dataset cifar100 --optimizer SGAP --type ForceRandom --topology ./topology/Ran6.txt --k 0.001 --v 0.1

# R18C10
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SGAP --type Static --topology ./topology/Full6.txt --k 0.1 --v 0.1
# python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer SGAP --type Static --topology ./topology/DC6.txt --k 0.01 --v 0.1
# python main.py --lr 0.01 --B 3 --model ResNet18 --dataset cifar10 --optimizer SGAP --type Exponential --topology ./topology/Exp6.txt --k 1.0 --v 0.1
# python main.py --lr 0.01 --B 8 --model ResNet18 --dataset cifar10 --optimizer SGAP --type ForceRandom --topology ./topology/Ran6.txt --k 0.1 --v 0.1

#MSGAP实验
# R50C100
python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer MSGAP --type Static --topology ./topology/Full6.txt --k 0.001 --v 0.1
python main.py --lr 0.1 --B 1 --model ResNet50 --dataset cifar100 --optimizer MSGAP --type Static --topology ./topology/DC6.txt --k 0.001 --v 0.1
python main.py --lr 0.1 --B 3 --model ResNet50 --dataset cifar100 --optimizer MSGAP --type Exponential --topology ./topology/Exp6.txt --k 0.001 --v 0.1
python main.py --lr 0.1 --B 8 --model ResNet50 --dataset cifar100 --optimizer MSGAP --type ForceRandom --topology ./topology/Ran6.txt --k 0.001 --v 0.1

# R18C10
#python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer MSGAP --type Static --topology ./topology/Full6.txt --k 0.01 --v 0.1
#python main.py --lr 0.01 --B 1 --model ResNet18 --dataset cifar10 --optimizer MSGAP --type Static --topology ./topology/DC6.txt --k 0.01 --v 0.1
#python main.py --lr 0.01 --B 3 --model ResNet18 --dataset cifar10 --optimizer MSGAP --type Exponential --topology ./topology/Exp6.txt --k 0.1 --v 0.1
#python main.py --lr 0.01 --B 8 --model ResNet18 --dataset cifar10 --optimizer MSGAP --type ForceRandom --topology ./topology/Ran6.txt --k 0.01 --v 0.1
