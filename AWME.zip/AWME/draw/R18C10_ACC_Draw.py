import numpy as np

import matplotlib
import matplotlib.pyplot as plt

path = "../evaluation/"

R18_C10_path = "R18_C10/"

path += R18_C10_path

SGPpath = path + 'SGP/'
SGAPpath = path + 'SGAP/'
SADDOPTpath = path + 'SADDOPT/'
MSGPpath = path + 'MSGP/'
MSGAPpath = path + 'MSGAP/'

SGPFullpath = SGPpath + 'Full6/lr_0.01CR.npy'
SGPDCpath = SGPpath + 'DC6/lr_0.01CR.npy'
SGPExppath = SGPpath + 'Exp6/lr_0.01CR.npy'
SGPRanpath = SGPpath + 'Ran6/lr_0.01CR.npy'

SGAPFullpath = SGAPpath + 'Full6/lr_0.01_v_0.1_k_0.1CR.npy'
SGAPDCpath = SGAPpath + 'DC6/lr_0.01_v_0.1_k_0.01CR.npy'
SGAPExppath = SGAPpath + 'Exp6/lr_0.01_v_0.1_k_1.0CR.npy'
SGAPRanpath = SGAPpath + 'Ran6/lr_0.01_v_0.1_k_0.1CR.npy'

SADDOPTFullpath = SADDOPTpath + 'Full6/lr_0.01CR.npy'
SADDOPTDCpath = SADDOPTpath + 'DC6/lr_0.01CR.npy'
SADDOPTExppath = SADDOPTpath + 'Exp6/lr_0.01CR.npy'
SADDOPTRanpath = SADDOPTpath + 'Ran6/lr_0.01CR.npy'

MSGPFullpath = MSGPpath + 'Full6/lr_0.01_mr_0.8CR.npy'
MSGPDCpath = MSGPpath + 'DC6/lr_0.01_mr_0.8CR.npy'
MSGPExppath = MSGPpath + 'Exp6/lr_0.01_mr_0.8CR.npy'
MSGPRanpath = MSGPpath + 'Ran6/lr_0.01_mr_0.8CR.npy'

MSGAPFullpath = MSGAPpath + 'Full6/lr_0.01_mr_0.8_v_0.1_k_0.01CR.npy'
MSGAPDCpath = MSGAPpath + 'DC6/lr_0.01_mr_0.8_v_0.1_k_0.01CR.npy'
MSGAPExppath = MSGAPpath + 'Exp6/lr_0.01_mr_0.8_v_0.1_k_0.1CR.npy'
MSGAPRanpath = MSGAPpath + 'Ran6/lr_0.01_mr_0.8_v_0.1_k_0.01CR.npy'

SGPFullAcc = np.load(SGPFullpath,allow_pickle=True)[4:25]
SGPDCAcc = np.load(SGPDCpath,allow_pickle=True)[4:25]
SGPExpAcc = np.load(SGPExppath,allow_pickle=True)[4:25]
SGPRanAcc = np.load(SGPRanpath,allow_pickle=True)[4:25]

SGAPFullAcc = np.load(SGAPFullpath,allow_pickle=True)[4:25]
SGAPDCAcc = np.load(SGAPDCpath,allow_pickle=True)[4:25]
SGAPExpAcc = np.load(SGAPExppath,allow_pickle=True)[4:25]
SGAPRanAcc = np.load(SGAPRanpath,allow_pickle=True)[4:25]

SADDOPTFullAcc = np.load(SADDOPTFullpath,allow_pickle=True)[4:25]
SADDOPTDCAcc = np.load(SADDOPTDCpath,allow_pickle=True)[4:25]
SADDOPTExpAcc = np.load(SADDOPTExppath,allow_pickle=True)[4:25]
SADDOPTRanAcc = np.load(SADDOPTRanpath,allow_pickle=True)[4:25]

MSGPFullAcc = np.load(MSGPFullpath,allow_pickle=True)[4:25]
MSGPDCAcc = np.load(MSGPDCpath,allow_pickle=True)[4:25]
MSGPExpAcc = np.load(MSGPExppath,allow_pickle=True)[4:25]
MSGPRanAcc = np.load(MSGPRanpath,allow_pickle=True)[4:25]

MSGAPFullAcc = np.load(MSGAPFullpath,allow_pickle=True)[4:25]
MSGAPDCAcc = np.load(MSGAPDCpath,allow_pickle=True)[4:25]
MSGAPExpAcc = np.load(MSGAPExppath,allow_pickle=True)[4:25]
MSGAPRanAcc = np.load(MSGAPRanpath,allow_pickle=True)[4:25]

epoch=list(range(4,25))

path_img=path+'R18_C10_AccImg.jpg'

fig,((a1,a2),(a3,a4))=plt.subplots(2,2,sharex=False,sharey=False)
fig.set_figheight(9)
fig.set_figwidth(22)
plt.subplots_adjust(wspace=0.3,hspace=0)

x_major_locator=plt.MultipleLocator(5)


a1.plot(epoch,SGPFullAcc,color='r',marker='o',label='SGP',linewidth =2.5,markersize = 10)
a1.plot(epoch,MSGPFullAcc,color='y',marker='s',label='MSGP',linewidth =2.5,markersize = 10)
a1.plot(epoch,SGAPFullAcc,color='g',marker='v',label='SGAP',linewidth =2.5,markersize = 10)
a1.plot(epoch,MSGAPFullAcc,color='b',marker='x',label='MSGAP',linewidth =2.5,markersize = 10)
a1.plot(epoch,SADDOPTFullAcc,color='k',marker='d',label='S-ADDOPT',linewidth =2.5,markersize = 10)
a1.set_xlabel('Epochs',fontdict={'size':18},labelpad=-1)
a1.set_ylabel('Accuracy(%)',fontdict={'size':18})
#a1.set_ylim((50,70))
a1.tick_params(labelsize=14)
a1.xaxis.set_major_locator(x_major_locator)
a1.set_title('(a):Full',fontsize=20)
a1.legend(loc=2,prop = {'size':18})

a2.plot(epoch,SGPDCAcc,color='r',marker='o',label='SGP',linewidth =2.5,markersize = 10)
a2.plot(epoch,MSGPDCAcc,color='y',marker='s',label='MSGP',linewidth =2.5,markersize = 10)
a2.plot(epoch,SGAPDCAcc,color='g',marker='v',label='SGAP',linewidth =2.5,markersize = 10)
a2.plot(epoch,MSGAPDCAcc,color='b',marker='x',label='MSGAP',linewidth =2.5,markersize = 10)
a2.plot(epoch,SADDOPTDCAcc,color='k',marker='d',label='S-ADDOPT',linewidth =2.5,markersize = 10)
a2.set_xlabel('Epochs',fontdict={'size':18},labelpad=-1)
a2.set_ylabel('Accuracy(%)',fontdict={'size':18})
a2.tick_params(labelsize=14)
a2.xaxis.set_major_locator(x_major_locator)
a2.set_title('(b):Divide',fontsize=20)
a2.legend(loc=2,prop = {'size':18})

a3.plot(epoch,SGPExpAcc,color='r',marker='o',label='SGP',linewidth =2.5,markersize = 10)
a3.plot(epoch,MSGPExpAcc,color='y',marker='s',label='MSGP',linewidth =2.5,markersize = 10)
a3.plot(epoch,SGAPExpAcc,color='g',marker='v',label='SGAP',linewidth =2.5,markersize = 10)
a3.plot(epoch,MSGAPExpAcc,color='b',marker='x',label='MSGAP',linewidth =2.5,markersize = 10)
a3.plot(epoch,SADDOPTExpAcc,color='k',marker='d',label='S-ADDOPT',linewidth =2.5,markersize = 10)
a3.set_xlabel('Epochs',fontdict={'size':18},labelpad=-1)
a3.set_ylabel('Accuracy(%)',fontdict={'size':18})
a3.tick_params(labelsize=14)
a3.xaxis.set_major_locator(x_major_locator)
a3.set_title('(c):Exp',fontsize=20)
a3.legend(loc=0,prop = {'size':18})

a4.plot(epoch,SGPRanAcc,color='r',marker='o',label='SGP',linewidth =2.5,markersize = 10)
a4.plot(epoch,MSGPRanAcc,color='y',marker='s',label='MSGP',linewidth =2.5,markersize = 10)
a4.plot(epoch,SGAPRanAcc,color='g',marker='v',label='SGAP',linewidth =2.5,markersize = 10)
a4.plot(epoch,MSGAPRanAcc,color='b',marker='x',label='MSGAP',linewidth =2.5,markersize = 10)
a4.plot(epoch,SADDOPTRanAcc,color='k',marker='d',label='S-ADDOPT',linewidth =2.5,markersize = 10)
a4.set_xlabel('Epochs',fontdict={'size':18},labelpad=-1)
a4.set_ylabel('Accuracy(%)',fontdict={'size':18})
a4.tick_params(labelsize=14)
a4.xaxis.set_major_locator(x_major_locator)
a4.set_title('(d):Random',fontsize=20)
a4.legend(loc=0,prop = {'size':18})

fig.tight_layout()
plt.savefig(path_img)